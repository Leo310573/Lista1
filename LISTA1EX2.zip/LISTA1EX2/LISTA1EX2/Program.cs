﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1EX2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double resultado;
            Console.WriteLine("Exercício 2 da Lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor da Aresta: ");
            aresta = double.Parse(Console.ReadLine());

            resultado = Math.Pow(aresta, 2);
            Console.WriteLine("Resultado: {0}", resultado);
        }
    }
}
