﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1EX1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double altura;
            double resultado;
            Console.WriteLine("Exercício 1 da Lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor da Base: ");
            nbase = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor da Altura: ");
            altura = double.Parse(Console.ReadLine());
            resultado = nbase * altura;
            Console.WriteLine("Resultado: {0}", resultado);
        }
    }
}
