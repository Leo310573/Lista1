﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1EX5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double valor3;
            double valor4;
            double resultado;
            Console.WriteLine("Exercício 5 da Lista 1");
            Console.WriteLine("");
            Console.Write("Digite o primeiro valor: ");
            valor1 = double.Parse(Console.ReadLine());
            Console.Write("Digite o segundo valor: ");
            valor2 = double.Parse(Console.ReadLine());
            Console.Write("Digite o terceiro valor: ");
            valor3 = double.Parse(Console.ReadLine());
            Console.Write("Digite o quarto valor: ");
            valor4 = double.Parse(Console.ReadLine());
            resultado = (valor1 + valor2 + valor3 + valor4) / 4;
            Console.WriteLine("Resultado: {0}", resultado);
        }
    }
}
